from flask import Flask, request, render_template
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

app = Flask(__name__)

# Image upload path
UPLOAD_FOLDER = 'D:/UNIVERSITY/5th Semester/DLNN/DLNN Project/DS For project/images upload by user'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Try to load models
try:
    body_shape_model = load_model('D:/UNIVERSITY/5th Semester/DLNN/DLNN Project/FASTION RECOMENDATION SYSTEM/body_shape_resnet50_model.h5')
    outfit_model = load_model('D:/UNIVERSITY/5th Semester/DLNN/DLNN Project/FASTION RECOMENDATION SYSTEM/multi_label_outfit_recommendation_model.h5')
except Exception as e:
    print(f"Error loading models: {e}")
    exit(1)

# Route to upload image
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Check if an image is uploaded
    if 'image' not in request.files:
        return "No image uploaded", 400

    # Save the uploaded image
    file = request.files['image']
    if file.filename == '':
        return "No selected file", 400
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    # Preprocess the image
    img = image.load_img(file_path, target_size=(128, 128))  # Adjust to your model's input size
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0  # Normalize image

    # Step 1: Predict body shape
    body_shape_pred = body_shape_model.predict(img_array)
    body_shape_class = np.argmax(body_shape_pred, axis=1)

    # Body shape categories
    body_shape_dict = {
        0: "Rectangle",
        1: "Hourglass",
        2: "Pear",
        3: "Apple"
    }
    body_shape_name = body_shape_dict[body_shape_class[0]]

    # Step 2: Outfit recommendation based on body shape
    outfit_recommendations = {
        "Rectangle": ["T-Shirt", "Jeans", "Sneakers"],
        "Hourglass": ["Dress", "Heels"],
        "Pear": ["Shirt", "Jeans", "Shoes"],
        "Apple": ["Tunic", "Leggings", "Flats"]
    }
    recommended_outfit = outfit_recommendations.get(body_shape_name, ["No outfit available"])

    # Render the results template
    return render_template(
        'result.html',
        body_shape=body_shape_name,
        recommended_outfit=recommended_outfit,
        user_image=file.filename
    )

if __name__ == '__main__':
    app.run(debug=True, port=8000)
